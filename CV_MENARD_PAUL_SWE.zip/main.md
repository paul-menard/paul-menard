**Engineering student @ CentraleSupélec - Paris-Saclay University**\

# Education

# Professional Experience

# Projects

# Technical Skills

# Languages
